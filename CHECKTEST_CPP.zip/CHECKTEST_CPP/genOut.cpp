#include <bits/stdc++.h>
using namespace std;
int a,b;
int main() {
    freopen("ahaha.inp","r",stdin);
    freopen("ahaha.ans","w",stdout);
    cin>>a>>b;
    cout<<a+b;
}
